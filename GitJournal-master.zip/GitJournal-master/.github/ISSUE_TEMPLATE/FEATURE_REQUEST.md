<!--
SPDX-FileCopyrightText: 2019-2021 Vishesh Handa <me@vhanda.in>
SPDX-FileCopyrightText: 2019-2021 deandreamatias <deandreamatias@gmail.com>

SPDX-License-Identifier: CC-BY-4.0
-->

---
name: Feature request
about: Suggest an idea for this project

---

## Environment

**App version:**
**Device information:**
 - OS name and version:
 - Manufacturer:
 - Model:

## Description

**What you'd like to happen:**

**Alternatives you've considered:** <!-- if available, else delete -->  

**Images:** <!-- if available, else delete -->  
