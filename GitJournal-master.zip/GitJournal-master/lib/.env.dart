// SPDX-FileCopyrightText: 2019-2021 Vishesh Handa <me@vhanda.in>
//
// SPDX-License-Identifier: AGPL-3.0-or-later

class Env {
  static final String analyticsUrl = "";
  static final String sentry = "";
}
