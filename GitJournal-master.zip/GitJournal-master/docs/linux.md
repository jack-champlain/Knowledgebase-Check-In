Some Data is stored in .local/share/gitjournal
SharedPref are also stored there

App Data is in ~/Documents
