QA Process -

* Make a note
* Setup GitHub as provider
* Make sure this note in in the repo
* Add a new note
* Edit a note
* Remove a note

* Try starting the app in Flight Mode

--
* Try setting up GitLab / GitHub - with existing repos
  and try again with fresh repos
