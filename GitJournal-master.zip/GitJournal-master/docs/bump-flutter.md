# Upgrade Flutter

- [ ] Look the release notes

- [ ] Upgrade flutter-android-sdk
- [ ] Upgrade pubspec.yaml
- [ ] Upgrade flutterw

- [ ] Run `dart fix --apply`
- [ ] Check `flutter analyze`
- [ ] Run all the tests
- [ ] Run `pod repo update`, `pod install` and `pod update Sentry` on ios + macos folders
