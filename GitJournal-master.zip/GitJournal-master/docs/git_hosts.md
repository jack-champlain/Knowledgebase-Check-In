# List of Git Hosts

Git Providers -
* GitHub
* GitLab.org
* BitBucket
* SourceForge
* Launchpad
* BeanStalkApp
* Google Cloud Source Repositories
* AWS Code Commit
* Azure Repos

Self Hosting -
* Plain SSH
* Gitea
* Gogs
* GitLab
* Gitolite
* Apache Allura
* Kallithea
* Phabricator
* GitBucket
* GitPrep
